<?php
    $this->load->view('admin/parts/header');
    $this->load->view('admin/project/create');
    $this->load->view('admin/parts/footer');
?>