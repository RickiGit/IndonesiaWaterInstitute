<?php
    $this->load->view('admin/parts/header');
    $this->load->view('admin/teams/index');
    $this->load->view('admin/parts/footer');
?>