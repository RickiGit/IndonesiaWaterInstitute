<?php
    $this->load->view('public/parts/header');
    $this->load->view('public/media/book');
    $this->load->view('public/parts/footer');
?>