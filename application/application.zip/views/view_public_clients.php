<?php
    $this->load->view('public/parts/header');
    $this->load->view('public/clients/index');
    $this->load->view('public/parts/footer');
?>