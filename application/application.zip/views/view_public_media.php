<?php
    $this->load->view('public/parts/header');
    $this->load->view('public/media/index');
    $this->load->view('public/parts/footer');
?>