<?php
    $this->load->view('admin/parts/header');
    $this->load->view('admin/teams/edit');
    $this->load->view('admin/parts/footer');
?>