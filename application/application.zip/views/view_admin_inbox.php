<?php
    $this->load->view('admin/parts/header');
    $this->load->view('admin/inbox/index');
    $this->load->view('admin/parts/footer');
?>