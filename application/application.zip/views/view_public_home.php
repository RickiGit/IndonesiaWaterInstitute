<?php
    $this->load->view('public/parts/header');
    $this->load->view('public/home/index');
    $this->load->view('public/parts/footer');
?>