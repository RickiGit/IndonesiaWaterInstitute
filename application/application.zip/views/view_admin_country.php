<?php
    $this->load->view('admin/parts/header');
    $this->load->view('admin/client/index_country');
    $this->load->view('admin/parts/footer');
?>