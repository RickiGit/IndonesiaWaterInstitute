<?php
    $this->load->view('admin/parts/header');
    $this->load->view('admin/project/index');
    $this->load->view('admin/parts/footer');
?>