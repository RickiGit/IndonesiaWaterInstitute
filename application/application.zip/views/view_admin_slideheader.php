<?php
    $this->load->view('admin/parts/header');
    $this->load->view('admin/slideheader/index');
    $this->load->view('admin/parts/footer');
?>