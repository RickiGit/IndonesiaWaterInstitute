<?php
    $this->load->view('public/parts/header');
    $this->load->view('public/media/detailnews');
    $this->load->view('public/parts/footer');
?>