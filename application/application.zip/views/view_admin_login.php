<?php
    $this->load->view('admin/login/index');
?>