<?php
    $this->load->view('public/parts/header');
    $this->load->view('public/projects/detail');
    $this->load->view('public/parts/footer');
?>