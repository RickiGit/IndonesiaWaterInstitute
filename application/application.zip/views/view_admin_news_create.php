<?php
    $this->load->view('admin/parts/header');
    $this->load->view('admin/news/create');
    $this->load->view('admin/parts/footer');
?>