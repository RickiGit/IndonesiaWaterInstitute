<?php
    $this->load->view('admin/parts/header');
    $this->load->view('admin/contact/edit');
    $this->load->view('admin/parts/footer');
?>