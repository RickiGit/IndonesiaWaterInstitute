<?php
    $this->load->view('admin/parts/header');
    $this->load->view('admin/about/edit');
    $this->load->view('admin/parts/footer');
?>