<?php
    $this->load->view('public/parts/header');
    $this->load->view('public/about/index');
    $this->load->view('public/parts/footer');
?>