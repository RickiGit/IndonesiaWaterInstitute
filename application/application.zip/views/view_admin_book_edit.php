<?php
    $this->load->view('admin/parts/header');
    $this->load->view('admin/book/edit');
    $this->load->view('admin/parts/footer');
?>