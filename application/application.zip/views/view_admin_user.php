<?php
    $this->load->view('admin/parts/header');
    $this->load->view('admin/user/index');
    $this->load->view('admin/parts/footer');
?>