<?php
    $this->load->view('admin/parts/header');
    $this->load->view('admin/client/edit_country');
    $this->load->view('admin/parts/footer');
?>